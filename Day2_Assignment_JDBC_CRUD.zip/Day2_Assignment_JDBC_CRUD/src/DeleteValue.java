import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteValue {
	
	//To connect to table employee in mysql database --	
	static final String DB_url="jdbc:mysql://localhost:3306/cognidemo";
	static final String user="root";
	static final String password="pass@word1";
	static final String query="delete from customer where customer_id=?";

	public static void main(String[] args) {
		try(
				Connection conn=DriverManager.getConnection(DB_url,user,password);
				PreparedStatement pst=conn.prepareStatement(query);
				)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Customer's ID you want to delete: ");
			int cust_id=sc.nextInt();
			
			pst.setInt(1, cust_id);
			pst.executeUpdate();
			
			System.out.println("*****Record of customer_id = "+cust_id+" deleted*****");
			sc.close();
			
			
		}catch(SQLException e) {
			e.printStackTrace();
			}
	}

}
