import java.sql.Connection;
//import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.util.Date;
import java.util.Scanner;

public class InsertingValues {
	
	//To connect to table employee in mysql database --	
		static final String DB_url="jdbc:mysql://localhost:3306/cognidemo";
		static final String user="root";
		static final String password="pass@word1";
		static final String query="insert into customer"
				+ "(customer_id,customer_name,customer_address,customer_phone,"
				+ "customer_gender,customer_religion,customer_dob)"
				+ "values(?,?,?,?,?,?,?)";
		static String flag="yes";

	public static void main(String[] args) {
		try(
				Connection conn=DriverManager.getConnection(DB_url, user, password);
				PreparedStatement pst=conn.prepareStatement(query);
				)
		{
			while(flag.equalsIgnoreCase("yes")) 
			{
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter Customer ID: ");
				int cust_id=sc.nextInt();
				System.out.println("Enter Customer name: ");
				String cust_name=sc.next();
				System.out.println("Enter Customer address: ");
				String cust_address=sc.next();
				System.out.println("Enter Customer phone: ");
				long cust_phone=sc.nextLong();
				System.out.println("Enter Customer gender as M/F/O: ");
				char cust_gender=sc.next().charAt(0);
				System.out.println("Enter Customer religion: ");
				String cust_religion=sc.next();
				System.out.println("Enter Customer date of birth in yyyy-mm-dd format: ");
				String cust_dob=sc.next();
				
	//			DateFormat dateFormatYMD=new SimpleDateFormat("YYYY/MM/DD");
	//			Date now = new Date();
	//			String dateYMD=dateFormatYMD.format(now);
	//			java.sql.Date date=new java.sql.Date(0000-00-00);
				
	//			DateTimeFormatter format=DateTimeFormatter.ofPattern("yyyy-mm-dd");
	//			LocalDateTime cust_dob=LocalDateTime.parse(sc.next(), format);
				
	//			ToolBox.readDate(sc,"yyyy-mm-dd");
	//			public static Date readDate(Scanner sc, String format) {
	//				return new SimpleDateFormat(format).parse(sc.nextLine);
	//			}
				
				pst.setInt(1, cust_id);
				pst.setString(2, cust_name);
				pst.setString(3, cust_address);
				pst.setLong(4, cust_phone);
				pst.setString(5, String.valueOf(cust_gender));
				pst.setString(6, cust_religion);
				pst.setDate(7, java.sql.Date.valueOf(cust_dob));
				pst.executeUpdate();
				System.out.println("Record inserted");
				System.out.println("Do you want to continue? : yes/no");
				String option=sc.next();
				flag=option;
				//sc.close();
			}System.exit(0);
		}catch (SQLException e) {
			e.printStackTrace();}
	}
}