import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RetrieveAllRecords {
	
	//To connect to table employee in mysql database --	
	static final String DB_url="jdbc:mysql://localhost:3306/cognidemo";
	static final String user="root";
	static final String password="pass@word1";
	static final String query="select * from customer";

	public static void main(String[] args) {
		try(
				Connection conn=DriverManager.getConnection(DB_url,user,password);
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery(query);
				)
		{
			while(rs.next()) {
				System.out.println("Customer ID = "+ rs.getInt("customer_id"));
				System.out.println("Customer Name = "+ rs.getString("customer_name"));
				System.out.println("Customer Address = "+ rs.getString("customer_address"));
				System.out.println("Customer Contact = "+ rs.getString("customer_phone"));
				System.out.println("Customer Gender = "+ rs.getString("customer_gender"));
				System.out.println("Customer Religion = "+ rs.getString("customer_religion"));
				System.out.println("Customer DOB in YYYY-MM-DD format = "+ rs.getString("customer_dob"));
				System.out.println("----------------------------------------------------------");
			}
			System.out.println("*****All records retrieved*****");

		}catch(SQLException e) {
			e.printStackTrace();}
	}

}