//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.Scanner;
//
//public class UpdateValues {
//	
//	//To connect to table employee in mysql database --	
//		static final String DB_url="jdbc:mysql://localhost:3306/cognidemo";
//		static final String user="root";
//		static final String password="pass@word1"; 
//
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Please enter customer id you want to update");
//		int cust_id=sc.nextInt();
//		System.out.println("Enter name to update: ");
//		String cust_name=sc.next();
//		System.out.println("Enter address to update: ");
//		String cust_address=sc.next();
//		
//		//String update = "update customer set customer_name=?, customer_address=? where customer_id=?";
//		String update="update customer set customer_name="+cust_name+"customer_address="+cust_address+
//				"where cust_id="+cust_id;
//		String query="select * from customer";
//		
//		try(Connection conn=DriverManager.getConnection(DB_url,user,password);
//				PreparedStatement pst=conn.prepareStatement(update);
//						ResultSet rs=pst.executeQuery(query);)
//		{
////			System.out.println("Enter name to update: ");
////			String cust_name=sc.next();
////			System.out.println("Enter address to update: ");
////			String cust_address=sc.next();
//			pst.setString(1, cust_name);
//			pst.setString(2, cust_address);
//			pst.executeUpdate();
//			
//			while(rs.next()) {
//				System.out.println("Customer ID = "+ rs.getInt("customer_id"));
//				System.out.println("Customer Name = "+ rs.getString("customer_name"));
//				System.out.println("Customer Address = "+ rs.getString("customer_address"));
//				System.out.println("Customer Contact = "+ rs.getString("customer_phone"));
//				System.out.println("Customer Gender = "+ rs.getString("customer_gender"));
//				System.out.println("Customer Religion = "+ rs.getString("customer_religion"));
//				System.out.println("Customer DOB in YYYY-MM-DD format = "+ rs.getString("customer_dob"));
//				System.out.println("----------------------------------------------------------");
//			}
//			System.out.println("*****Record of customer_id = "+cust_id+" retrieved*****");
//			sc.close();
//			
////			pst.setString(1, cust_name);
////			pst.setString(2, cust_address);
////			pst.setInt(3, cust_id);
////			
//			//System.out.println(pst.getResultSet());
////			pst.executeUpdate();
//			
//		}catch(SQLException e) {
//			e.printStackTrace();
//			}
//	}
//
//}


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateValues {
	
	//To connect to table employee in mysql database --	
		static final String DB_url="jdbc:mysql://localhost:3306/cognidemo";
		static final String user="root";
		static final String password="pass@word1";
		static final String query="update customer set customer_name=?, customer_address=? where customer_id=?";

	public static void main(String[] args) {
		try(
				Connection conn=DriverManager.getConnection(DB_url,user,password);
				PreparedStatement pst=conn.prepareStatement(query);
				)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter customer ID you want to update:");
			int cust_id=sc.nextInt();
			System.out.println("Enter name to update: ");
			String cust_name=sc.next();
			System.out.println("Enter address to update: ");
			String cust_address=sc.next();
			
			pst.setString(1, cust_name);
			pst.setString(2, cust_address);
			pst.setInt(3, cust_id);
			
			pst.executeUpdate();
			
			System.out.println("*****Record of customer_id = "+cust_id+" updated*****");
			sc.close();
			
		}catch(SQLException e) {
			e.printStackTrace();
			}
	}

}
