import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SignIn {
	
	//To connect to table employee in mysql database --	
		static final String DB_url="jdbc:mysql://localhost:3306/food_order_app";
		static final String DB_user="root";
		static final String DB_password="pass@word1";
		
		static final String sign_in_query="select * from signup where email=? and password=?;";
		static final String insert_query="insert into orders(email,burger,fries,colddrink,pizza,smoothie) values(?,?,?,?,?,?);";
		static final String update_query="update orders set burger=?,fries=?,colddrink=?,pizza=?,smoothie=? where email=?";
		static final String retrieve_query="select * from signup";
		static final String delete_query="delete from orders where email=?";
		
		static String flag="yes";

		public static void main(String[] args) {
			try(Connection conn1=DriverManager.getConnection(DB_url,DB_user,DB_password);
					PreparedStatement pst1=conn1.prepareStatement(sign_in_query);)
			{
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter email: ");
				String email=sc.next();
				System.out.println("Enter password: ");
				String password=sc.next();
				
				pst1.setString(1, email);
				pst1.setString(2, password);
				ResultSet rs1=pst1.executeQuery();
				if(rs1.next()) {
					System.out.println('\n'+"**************Login Successful**************"+'\n');
					while(flag.equalsIgnoreCase("yes")) 
					{
						System.out.println("Enter choice:"+'\n'+"1.Insert"+'\n'+"2.Update"+'\n'+"3.Retrieve"+'\n'+"4.Delete");
						String choice=sc.next();
						switch(choice) {
						case "insert":
						case "1":
						{
							try(Connection conn2=DriverManager.getConnection(DB_url,DB_user,DB_password);
									PreparedStatement pst2=conn2.prepareStatement(insert_query);)
							{
								System.out.println("Email: "+ email);
								System.out.println("Enter no. of burgers you want: ");
								int burger=sc.nextInt();
								System.out.println("Enter no. of fries you want: ");
								int fries=sc.nextInt();
								System.out.println("Enter no. of cold drink you want: ");
								int cold_drink=sc.nextInt();
								System.out.println("Enter no. of pizza you want: ");
								int pizza=sc.nextInt();
								System.out.println("Enter no. of smoothie you want: ");
								int smoothie=sc.nextInt();

								pst2.setString(1, email);
								pst2.setInt(2, burger);
								pst2.setInt(3, fries);
								pst2.setInt(4, cold_drink);
								pst2.setInt(5, pizza);
								pst2.setInt(6, smoothie);
								pst2.executeUpdate();
								System.out.println("*****Order placed*****");
								//sc.close();
							}catch (SQLException e) {
								e.printStackTrace();
							}
						}
						System.out.println("Do you want to continue? : yes/no");
						String option1=sc.next();
						flag=option1;
						if(flag.equalsIgnoreCase("yes")) {continue;}
						else {break;}
						case "update":
						case "2":
						{
							try(Connection conn3=DriverManager.getConnection(DB_url,DB_user,DB_password);
									PreparedStatement pst3=conn3.prepareStatement(update_query);)
							{
								System.out.println("Enter email of order you want to update:");
								String email_id=sc.next();
								System.out.println("Enter updated no. of burgers you want: ");
								int burger=sc.nextInt();
								System.out.println("Enter updated no. of fries you want: ");
								int fries=sc.nextInt();
								System.out.println("Enter updated no. of cold drink you want: ");
								int cold_drink=sc.nextInt();
								System.out.println("Enter updated no. of pizza you want: ");
								int pizza=sc.nextInt();
								System.out.println("Enter updated no. of smoothie you want: ");
								int smoothie=sc.nextInt();

								pst3.setInt(1, burger);
								pst3.setInt(2, fries);
								pst3.setInt(3, cold_drink);
								pst3.setInt(4, pizza);
								pst3.setInt(5, smoothie);
								pst3.setString(6, email);
								pst3.executeUpdate();
								System.out.println("*****Order of email_id = "+email_id+" updated*****");
							}catch(SQLException e) {
								e.printStackTrace();
							}
						}
						System.out.println("Do you want to continue? : yes/no");
						String option2=sc.next();
						flag=option2;
						if(flag.equalsIgnoreCase("yes")) {continue;}
						else {break;}
						case "retrieve":
						case "3":
						{
							try(
									Connection conn4=DriverManager.getConnection(DB_url,DB_user,DB_password);
									Statement st=conn4.createStatement();
									ResultSet rs2=st.executeQuery(retrieve_query);
									)
							{
								while(rs2.next()) {
									System.out.println("Customer First Name = "+ rs2.getString("first_name"));
									System.out.println("Customer Last Name = "+ rs2.getString("last_name"));
									System.out.println("Customer Email = "+ rs2.getString("email"));
									System.out.println("Customer Password = "+ rs2.getString("password"));
									System.out.println("Customer Phone Number = "+ rs2.getLong("phone_no"));
									System.out.println("Customer Order ID = "+ rs2.getInt("order_id"));
									System.out.println("----------------------------------------------------------");
								}
								System.out.println("*****All customer records retrieved*****");
							}catch(SQLException e) {
								e.printStackTrace();
							}
						}
						System.out.println("Do you want to continue? : yes/no");
						String option3=sc.next();
						flag=option3;
						if(flag.equalsIgnoreCase("yes")) {continue;}
						else {break;}
						case "delete":
						case "4":
						{
							try(Connection conn5=DriverManager.getConnection(DB_url,DB_user,DB_password);
									PreparedStatement pst4=conn5.prepareStatement(delete_query);)
							{
								System.out.println("Enter Customer's email, whose order you want to delete: ");
								String email_id=sc.next();

								pst4.setString(1, email_id);
								pst4.executeUpdate();

								System.out.println("*****Order of customer "+email_id+" deleted*****");
							}catch(SQLException e) {
								e.printStackTrace();
							}
						}
						System.out.println("Do you want to continue? : yes/no");
						String option4=sc.next();
						flag=option4;
						if(flag.equalsIgnoreCase("yes")) {continue;}
						else {break;}
						}
					}
				}
				else {
					System.out.println("*********Oops! Login Failed Try Again***********");	}
				sc.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
}