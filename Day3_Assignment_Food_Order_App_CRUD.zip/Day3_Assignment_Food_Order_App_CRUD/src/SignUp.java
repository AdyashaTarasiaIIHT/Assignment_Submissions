import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class SignUp {
	
	//To connect to table employee in mysql database --	
	static final String DB_url="jdbc:mysql://localhost:3306/food_order_app";
	static final String user="root";
	static final String password="pass@word1";
	static final String query="insert into signup(first_name,last_name,email,password,phone_no,order_id)"
			+ "values(?,?,?,?,?,?)";
	static int order_id=0;
	static String flag="yes";

	public static void main(String[] args) {
		try(Connection conn=DriverManager.getConnection(DB_url,user,password);
				PreparedStatement pst=conn.prepareStatement(query);)
		{
			while(flag.equalsIgnoreCase("yes"))
			{
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter first name: ");
				String fname=sc.next();
				System.out.println("Enter last name: ");
				String lname=sc.next();
				System.out.println("Enter email: ");
				String email=sc.next();
				System.out.println("Enter password: ");
				String password=sc.next();
				System.out.println("Enter phone_number: ");
				Long phone_no=sc.nextLong();
				System.out.println("---------------------------------------");
				order_id++;
				//int order_id=pst.setInt(6,order_id);
				System.out.println("Order ID generated: "+order_id);
				System.out.println("---------------------------------------");

				pst.setString(1, fname);
				pst.setString(2, lname);
				pst.setString(3, email);
				pst.setString(4, password);
				pst.setLong(5, phone_no);
				pst.setInt(6, order_id);
				pst.executeUpdate();
				System.out.println("Record inserted");
				System.out.println("Taking more orders? : yes/no");
				String option=sc.next();
				flag=option;
			}System.exit(0);
			
		}catch(SQLException e) {
			e.printStackTrace();
			}
	}

}
